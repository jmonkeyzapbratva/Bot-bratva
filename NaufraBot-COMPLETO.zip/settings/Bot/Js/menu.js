const Menu = ( timeFt , Bot , sender , groupName  , groupMembers ) => {  
return `
   『 𝐌𝐄𝐍𝐔 - 𝐏𝐑𝐈𝐍𝐂𝐈𝐏𝐀𝐋 』
╭══════════════════
│❐   ➢${timeFt} , 
 ❱  〄 @${sender.split('@')[0]} 
│❐  ꦿ𝐒𝐎𝐔: ${Bot}
│❐  ꦿ𝙋𝙍𝙀𝙁𝙄𝙓𝙊: !
│❐  ꦿ𝙂𝙍𝙐𝙋𝙊: ${groupName}
┃╭───────────────❍
┃│❍ 𝐂𝐎𝐌𝐎 𝐏𝐄𝐑𝐒𝐎𝐍𝐀𝐋𝐈𝐙𝐀𝐑 𝐎 𝐁𝐎𝐓 👇
┃│https://youtube.com/playlist?list=PLsjiVxv1dUKw1bKCmvj43AuUDYOm8ghPF&si=w0Fp_JLXcF8024x8
┃╰───────────────❍
╰━━━━━─「✪」─━━━━━
✪  𝙇𝙄𝙎𝙏𝘼 𝘿𝙀 𝘾𝙊𝙈𝘼𝙉𝘿𝙊𝙎
  ━━━━━─「✪」─━━━━━
╭
   ❍ 𝐌𝐄𝐍𝐔 𝐀𝐃𝐌𝐈𝐍  ❐
╰  
 ❱➢  〄welcome 1/0
 ❱➢  〄antilink 1/0      
 ❱➢  〄modoadmin 1/0
 ❱➢  〄todos
 ❱➢  〄anuncio
 ❱➢  〄ban
 ❱➢  〄kick
 ❱➢  〄notify
 ❱➢  〄rankrep
 ❱➢  〄rankcoins
 ❱➢  〄ranknivel
 
╭
    ❍ 𝐌𝐄𝐍𝐔 𝐃𝐎𝐍𝐎  ❐
╰  
 ❱➢  〄sercreador
 ❱➢  〄antiprivado            
 ❱➢  〄revelarvisu
 ❱➢  〄reiniciar
 ❱➢  〄bangp
 ❱➢  〄unbangp
 ❱➢  〄boton
 ❱➢  〄botoff
╭
  ❍ 𝐌𝐄𝐍𝐔 𝐃𝐎𝐖𝐍𝐋𝐎𝐀𝐃𝐒  ❐
╰
 ❱➢  〄play
 ❱➢  〄playvideo
 ❱➢  〄tiktokvideo
 ❱➢  〄tiktokaudio           
 ❱➢  〄buscarapk
 ❱➢  〄descargarapk
      
╭
  ❍ 𝐌𝐄𝐍𝐔 𝐈𝐍𝐅𝐎  ❐
╰
 ❱➢  〄ping
 ❱➢  〄perfil
 ❱➢  〄botcompleto        
 ❱➢  〄grupos
 ❱➢  〄canales 
 ❱➢  〄serbot 
                  
╭
   ❍ 𝐌𝐄𝐍𝐔 𝐀𝐓𝐈𝐕𝐎𝐒  ❐
╰
 ❱➢  〄sticker
 ❱➢  〄attp
 ❱➢  〄attp2
 ❱➢  〄attp3
 ❱➢  〄Emojimix           
      
╭  
   ❍ 𝐌𝐄𝐍𝐔 𝐅𝐄𝐑𝐑𝐀𝐌𝐄𝐍𝐓𝐀𝐒  ❐
╰   
 ❱➢  〄toimg
 ❱➢  〄tomp3      
 ❱➢  〄calc
 ❱➢  〄nick      
 ❱➢  〄ia
 ❱➢  〄chatgpt
 

╭                    
   ❍ 𝐌𝐄𝐍𝐔 - 𝐄𝐂𝐎𝐍𝐎𝐌𝐈𝐀  ❐       
╰      
 ❱➢  〄Nivel
 ❱➢  〄perfil
 ❱➢  〄cartera
 ❱➢  〄reg
 ❱➢  〄listreg
 ❱➢  〄ruleta 
 ❱➢  〄levelup
 ❱➢  〄minar
 ❱➢  〄regalar
 ❱➢  〄mireputacion
 ❱➢  〄tragamonedas
 ❱➢  〄dayli   
 ❱➢  〄pescar         
 ❱➢  〄tienda     
 ❱➢  〄casar 
          
`}
module.exports = Menu 

